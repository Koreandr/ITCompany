﻿using ITCompany_v1._0.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITCompany_v1._0.Models
{
   public class ProjectManagerModel
    {
        public int Id { get; set; }
        public virtual ProjectTasksModel ProjectTasksModel { get; set; }
        public virtual UserModel Users { get; set; }
    }
}
