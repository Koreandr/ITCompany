﻿using ITCompany_v1._0.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ITCompany_v1._0.DBConnect
{
    class DBInitializer : CreateDatabaseIfNotExists<MainDataBase>
    {
        UsersRepository _usersRepository;
       

        protected override void Seed(MainDataBase dataBase)
        {
            _usersRepository = new UsersRepository(dataBase);
           
        }
    }
}
