﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ITCompany_v1._0.Migration
{
    //internal sealed class Configuration : DbMigrationsConfiguration<ITCompany_v1.DBConnection.MainDataBase>
    //{
    //    public Configuration()
    //    {
    //        //AutomaticMigrationsEnabled = false;
    //        AutomaticMigrationsEnabled = true;
    //        ContextKey = "WpfMessenger.DBConnection.MainContext";
    //    }
    //}
}
